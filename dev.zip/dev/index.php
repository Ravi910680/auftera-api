



<?php
session_start();
$id=$_SESSION['id'];
    $mail=$_SESSION["email"];
    




?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">
 <link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968160/dashboard-js/argon-dashboard_btsvzb.css" rel="stylesheet" />
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<link href='https://fonts.googleapis.com/css?family=Karla:700' rel='stylesheet' type='text/css'>
<!-- Latest compiled JavaScript -->


<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet"> 
<style>

@import url(https://fonts.googleapis.com/css?family=Josefin+Sans);
@import url(https://fonts.googleapis.com/css?family=Arvo);
.tablediv{
    padding:10%;
}

.temp_con{
    padding:20px;width:fit-content;border-radius:5px;border:1px solid rgb(0 0 0 / 18%);
    margin-bottom:20px;
background:white;
    
}
.temp_con:hover{
    cursor:pointer;
    
}
.row{
margin-left:0px !important;
margin-right:0px !important;
}
.temp_name_sty{
padding-top: 20px;
width:180px;;
    color: #341161;
    font-family: 'Nunito Sans','Avenir Next','Segoe UI','Open Sans','Helvetica Neue',Helvetica,Arial,sans-serif;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-size: 17px;
    font-weight: 540;
    letter-spacing: 0.8px;
}
.btn-my:hover{
    outline:2px solid;
    cursor:pointer;

}
.card:hover{
    cursor:default;
}
.btn-my{
    height:50px;text-align:center;background:#f2f2f2;border:none;
    
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}




.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    float: right;
    padding-left: 20px;
    padding-right: 20px;
}




.nav-link:hover{
    cursor:pointer;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}


.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}



.addsiteheadbtn:hover{
    color:black;
    cursor:pointer;
    background:#d9d7cd;

}

#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    padding:20px !important;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}
.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    float: right;
    padding-left: 20px;
    padding-right: 20px;
}
.bottom-btn:hover{
	cursor: pointer;
}

.bottom-btn:focus{
  outline: none !important;
}
.bottom-btn:active{
  outline: none !important;
}




.res_of_hepta {
    padding: 10px;
    background: #0700ff1f;
    color: black;
    font-weight: 600;
    border-radius: 5px;
    border: 4px solid #0008ff4f;
display:none;


}



.not-fd-data{
  text-align: center;
padding: 40px;
    background: white;
    border-radius: 4px;

}




.txt-not-fd{
  padding-top: 20px;
    padding-bottom: 20px;
    width: 500px;
    margin: 0px auto;
    font-weight: 600;
    color: #080808cf;
}



.note-editable {
    line-height: 2;
}

.nav-link{
  color: #525f7f;
  font-size: 14px;
    font-weight: 500 !important;
}

.card{
  height: min-content;
  width: 30rem;
  border: 1px solid rgb(0 0 0 / 18%);

  
}

.head-cons-desg{
  padding: 50px 0px;
}

.card-img-top{
height: 200px;
    padding: 40px;


}

.card-body{
  text-align: center;
}

.card-text{
  font-weight: 500;
  color: black;
}

.card-title {
    margin-bottom: 1.25rem;
    font-size: 20px;
color: black;
    }

    a.crt-api-btn {
    color: #3368fa;
    background-color: #fff;
    border-color: #3368fa;
    font-family: Colfax-Bold,Helvetica,Arial,sans-serif;
    font-style: normal;
    font-weight: 600;
    display: inline-block;
    padding: 12px 32px;
    font-size: 16px;
    line-height: normal;
    text-align: center;
    border: 2px solid transparent;
    border-radius: 3px;
    outline: 0;
    box-shadow: 0 2px 4px 0 #c8d7ee;
    transition: all .2s ease-in-out;
    border: 2px solid;

  }



</style>


<style type="text/css">



.pdfobject-container {
  height: 30rem;
  border: 1rem solid rgba(0, 0, 0, 0.1);
}

.trigger {
  margin: 0 0.75rem;
  padding: 0.625rem 1.25rem;
  border: none;
  border-radius: 0.25rem;
  box-shadow: 0 0.0625rem 0.1875rem rgba(0, 0, 0, 0.12), 0 0.0625rem 0.125rem rgba(0, 0, 0, 0.24);
  transition: all 0.25s cubic-bezier(0.25, 0.8, 0.25, 1);
  font-size: 0.875rem;
  font-weight: 300;
}
.trigger i {
  margin-right: 0.3125rem;
}
.trigger:hover {
  
}

.modal {
  position: fixed;
  top: 0;
  left: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 0vh;
  background-color: transparent;
  overflow: hidden;
  transition: background-color 0.25s ease;
  z-index: 9999;
}
.modal.open {
  position: fixed;
  width: 100%;
  height: 100vh;
  background-color: rgba(0, 0, 0, 0.5);
  transition: background-color 0.25s;
}
.modal.open > .content-wrapper {
  transform: scale(1);
}
.modal .content-wrapper {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  width: 40%;
  margin: 0;
  padding: 2.5rem;
  background-color: white;
  border-radius: 0.3125rem;
  box-shadow: 0 0 2.5rem rgba(0, 0, 0, 0.5);
  transform: scale(0);
  transition: transform 0.25s;
  transition-delay: 0.15s;
}
.modal .content-wrapper .close {
  position: absolute;
  top: 0.5rem;
  right: 0.5rem;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 2.5rem;
  height: 2.5rem;
  border: none;
  background-color: transparent;
  font-size: 1.5rem;
  transition: 0.25s linear;
}
.modal .content-wrapper .close:before, .modal .content-wrapper .close:after {
  position: absolute;
  content: '';
  width: 1.25rem;
  height: 0.125rem;
  background-color: black;
}
.modal .content-wrapper .close:before {
  transform: rotate(-45deg);
}
.modal .content-wrapper .close:after {
  transform: rotate(45deg);
}
.modal .content-wrapper .close:hover:before, .modal .content-wrapper .close:hover:after {
  background-color: tomato;
}
.modal .content-wrapper .modal-header {
  position: relative;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  margin: 0;
  padding: 0 0 1.25rem;
}
.modal .content-wrapper .modal-header h2 {
  font-size: 1.5rem;
  font-weight: bold;
}
.modal .content-wrapper .content {
  position: relative;
  display: flex;
}
.modal .content-wrapper .content p {
  font-size: 0.875rem;
  line-height: 1.75;
}
.modal .content-wrapper .modal-footer {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  width: 100%;
  margin: 0;
  padding: 1.875rem 0 0;
}
.modal .content-wrapper .modal-footer .action {
  position: relative;
  margin-left: 0.625rem;
  padding: 0.625rem 1.25rem;
  border: none;
  background-color: slategray;
  border-radius: 0.25rem;
  color: white;
  font-size: 0.87rem;
  font-weight: 300;
  overflow: hidden;
  z-index: 1;
}
.modal .content-wrapper .modal-footer .action:before {
  position: absolute;
  content: '';
  top: 0;
  left: 0;
  width: 0%;
  height: 100%;
  background-color: rgba(255, 255, 255, 0.2);
  transition: width 0.25s;
  z-index: 0;
}
.modal .content-wrapper .modal-footer .action:first-child {
  background-color: #2ecc71;
}
.modal .content-wrapper .modal-footer .action:last-child {
  background-color: #e74c3c;
}
.modal .content-wrapper .modal-footer .action:hover:before {
  width: 100%;
}

.main-content{
  

height:84vh;background: white;overflow:scroll;


}

.main-content::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE, Edge and Firefox */
.main-content {
  -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}

.del-send-api-temp:hover {
    color: deeppink;
  }

  .not-fd-temp-api-data {
    width: 100%;
    text-align: center;
    padding: 20px;
    border: 1px solid rgb(0 0 0 / 18%);
    border-radius: 5px;
  }


  .suc_ret_dt {
    text-align: center;
    font-size: 40px;
    padding-top: 20px;
    color: midnightblue;

  }

  .rate-wrt_dt {
    width: 100px;
    margin: auto;
    height: 100px;
    padding: 20px;
    border-radius: 50%;
    border: 1px solid green;
    color: black !important;

  }

.rate-wrt_dt h2{

  color: midnightblue;
}



table {
  border-spacing: 1;
  border-collapse: collapse;
  background: white;
  border-radius: 6px;
  overflow: hidden;
  max-width: 90%;
  width: 100%;
  margin: 0 auto;
  position: relative;
}
table * {
  position: relative;
}
table td, table th {
  padding-left: 8px;
  font-weight: 500;
}
table thead tr {
 background: #19197040;
    color: midnightblue !important;

  height: 60px;
  
  font-size: 16px;
}
table tbody tr {
  height: 48px;
  border-bottom: 1px solid #E3F1D5;
  color: black;
  background: #f2f2f2ab;
}
table tbody tr:last-child {
  border: 0;
}
table td, table th {
  text-align: left;
}
table td.l, table th.l {
  text-align: right;
}
table td.c, table th.c {
  text-align: center;
}
table td.r, table th.r {
  text-align: center;
}

@media screen and (max-width: 35.5em) {
  table {
    display: block;
  }
  table > *, table tr, table td, table th {
    display: block;
  }
  table thead {
    display: none;
  }
  table tbody tr {
    height: auto;
    padding: 8px 0;
    color: #2d2222f7;
    font-weight: 200 !important;
  }
  table tbody tr td {
    padding-left: 45%;
    margin-bottom: 12px;
  }
  table tbody tr td:last-child {
    margin-bottom: 0;
  }
  table tbody tr td:before {
    position: absolute;
    font-weight: 700;
    width: 40%;
    left: 10px;
    top: 0;
  }
  table tbody tr td:nth-child(1):before {
    content: "Code";
  }
  table tbody tr td:nth-child(2):before {
    content: "Stock";
  }
  table tbody tr td:nth-child(3):before {
    content: "Cap";
  }
  table tbody tr td:nth-child(4):before {
    content: "Inch";
  }
  table tbody tr td:nth-child(5):before {
    content: "Box Type";
  }
}

div#send_api_history {
    padding-bottom: 100px;
  }










.wrapper{
  margin-left: auto;
}


.wrapper .search_box {
    width: 500px;
    color: black;
    background: #fff;
    border-radius: 5px;
    display: flex;
    height: 51px;
    padding: 3px;
    box-shadow: 0 8px 6px -10px #b3c6ff;
    border: 1px solid rgb(0 0 0 / 18%);

  }

.wrapper .search_box .dropdown-sel {
    width: 150px;
    border-right: 1px solid rgb(0 0 0 / 18%);
    position: relative;
    cursor: pointer;
    color: #4a154bd9;
    font-weight: 600;
  }

.wrapper .search_box .dropdown-sel .default_option{
  text-transform: uppercase;
  padding: 13px 15px;
  font-size: 14px;
}

.wrapper .search_box .dropdown-sel ul{
  position: absolute;
 
  background: #fff;
  width: 150px;
  border-radius: 5px;
  padding: 20px;
  display: none;
  border: 1px solid rgb(0 0 0 / 18%);
  z-index: 1;
    margin-top: 10px;
}

.wrapper .search_box .dropdown-sel ul.active{
  display: block;
}

.wrapper .search_box .dropdown-sel ul li{
  font-size: 13px;
  padding-bottom: 10px;
}

.wrapper .search_box .dropdown-sel ul li:last-child{
  padding-bottom: 0;
}

.wrapper .search_box .dropdown-sel ul li:hover{
  color: #6f768d;
}



.wrapper .search_box .search_field{
  width: 350px;
  height: 100%;
  position: relative;
}

.wrapper .search_box .search_field .input{
  width: 100%;
  height: 100%;
  border: 0px;
  font-size: 16px;
  padding-left: 20px;
  padding-right: 38px;
  color: #6f768d;
}

.wrapper .search_box .search_field .fad{
  position: absolute;
  top: 10px;
  right: 10px;
  font-size: 22px;
  color: #4a154bd9;
  cursor: pointer;
}

::-webkit-input-placeholder { /* Chrome/Opera/Safari */
  color: #9fa3b1;
}
::-moz-placeholder { /* Firefox 19+ */
 color: #9fa3b1;
}
:-ms-input-placeholder { /* IE 10+ */
  color: #9fa3b1;
}

input{
  border: none;
  outline: none;
}
i.fad.fa-chevron-down {
    margin-left: auto;
    float: right;
    font-size: 16px;
    color: #4a154bd9;
  }





.lds-color div{

border: 2px solid #4a154bd9 !important;border-color: #4a154bd9 transparent transparent transparent !important;

}


.lds-pos-cht{

  top: 50%;
  left: 50%;
}

.lds-pos-bg{
top: 50%;

}

.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid white;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: white transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}





.navbar-dark .navbar-nav .nav-link {
    color: #4a154b;
    font-size: 13px;
    font-weight: 600;

}


.navbar-dark .navbar-nav .nav-link:hover{

color:#4a154b;

}




.dis-non-crd-dt{

display:none;
}

</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  

 
  <!-- CSS Files -->
 
</head>
<div id="c"></div>
<body class="" style="">
  <?php require("./confige/header/header.html");?>

<div class="main-content container" style="top:0px;">



  <h2 class="head-cons-desg">API Console</h2>

<div class="row">

  <div class="card" >
  <img class="card-img-top" src="https://res.cloudinary.com/heptera/image/upload/v1598541694/checklist_wxzcqo.svg" alt="Card image cap" style="background: linear-gradient(150deg, rgba(82,76,187,1) 27%, rgba(70,69,144,1) 100%);">
  <div class="card-body">
    <h3 class="card-title">Managment API</h3>
    <p class="card-text">Management API Is used for manage contact of contact list. <b>show,delete,add</b> contact from contact list</p>
   
<div class=' ' id='acc-token-handl-1'>
    <a href="#" class="trigger crt-api-btn"   data-modal-trigger="modal-mngc-api-data">Create Key</a>
  </div>
  </div>
</div>



<div class="card" style="margin-left: auto;">
  <img class="card-img-top" src="https://res.cloudinary.com/heptera/image/upload/v1598541858/email_xftpdq.svg" alt="Card image cap" style="background: linear-gradient(150deg, rgba(144,69,96,1) 59%, rgba(187,76,101,1) 99%);">
  <div class="card-body">
    <h3 class="card-title">Sending API</h3>
    <p class="card-text">Sending API Is used to get send automayion of your system. like <b>OTP,transactonal message or create campign</b> from your automated system.</p>
   <div class=' ' id='acc-token-handl-2'>
    <a href="#" class="trigger crt-api-btn"   data-modal-trigger="modal-send-api-data">Create Key</a>
  </div>
  </div>
</div>


</div>


<div class='suc_api-hand-rat-fl-bx dis-non-crd-dt'>


<h2 class="head-cons-desg">API Success</h2>


<div id='success_rate_data' class='row'>



<div class="card dis-non-crd-dt" id='suc-send-dis-1' style="">
 <div class='suc_ret_dt'><i class="fad fa-tasks"></i></div>
  <div class="card-body">
    <h3 class="card-title">Manage API Success</h3>
    <p class="card-text">Successfully handle Manage Api Request is</p>
  
  <div class="rate-wrt_dt"><h2><span id='suc-rate-of-api-1' class='lds_set_data'>0
</span> <sub>request</sub></h2></div>
  </div>
</div>




<div class="card dis-non-crd-dt" id='suc-send-dis-2' style="margin-left: auto;">
 <div class='suc_ret_dt'><i class="fad fa-paper-plane"></i></div>
  <div class="card-body">
    <h3 class="card-title">Sending API Success</h3>
    <p class="card-text">Successfully handle Send Api Request is</p>
    <div class="rate-wrt_dt"><h2><span id='suc-rate-of-api-2' class='lds_set_data'>0</span> <sub>request</sub></h2></div>
  
  </div>
</div>


</div>

</div>

<h2 class="head-cons-desg">API Template</h2>


<div id='temp_to_res' class='row lds_set_data'></div>







<div class="head-cons-desg row">
  <div class="head-cls-name">
<h2 class="">Send API History</h2>
</div>


<div class="wrapper">
    <div class="search_box">
        <div class="dropdown-sel">
            <div class="default_option" id="src_fld_sel"><span id="all">All</span><i class="fad fa-chevron-down"></i></div>  
            <ul>
              <li><span id='all'>All</span></li>
              <li><span id='lst_id'>List</li>
              <li><span id='con_id'>Email</li>
              <li><span id='tag'>Tag</li>
              <li><span id='content_dt'>Content</li>
              <li><span id='status'>Status</li>

            </ul>
        </div>
        <div class="search_field">
          <input type="text" class="input" id='src_fld_val' placeholder="Search">
          <i class="fad fa-search" id='trg_of_src_lst_dt'></i>
      </div>
    </div>
</div>

</div>

<div id='send_api_history' class='row lds_set_data'>


<div class="not-fd-temp-api-data"> <i class="fad fa-acorn" aria-hidden="true" style=" font-size: 90px; color: #b50a67; "></i> <div class="txt-data-nt-fd"> Not found any template data for API connect. </div> </div>


</div>


</div>








<nav class="navbar navbar-expand-sm bg-dark navbar-dark" style="height:8vh;background: #4a154b14 !important;">
<ul class="navbar-nav">
<li class="nav-item">
<a class="nav-link lnk-of-foot-nav" href="#" style="font-weight:700;">heptera|<sub>Studio</sub></a>
</li>
<li class="nav-item">
<a class="nav-link lnk-of-foot-nav" href="../../template/" style="font-weight:600;">Template</a>
</li>
<li class="nav-item">
<a class="nav-link lnk-of-foot-nav" href="#" style="font-weight:700;">More About</a>
</li>
</ul>
</nav>



<style type="text/css">

.modal-header h2{

  color: black;
}
.content p{

color: #000000ab;
    font-weight: 500;

}

a.crt-api-btn-fin {
    background-color: #3368fa;
    color: white;
    padding: 10px;
    font-size: 15px;
    border-radius: 3px;

  }

  .cont-of-res-api-tok {
    border: 1px solid #a59f9f !important;
    border-radius: 5px;
    color: #777373;
    width: 70%;
  }

  input.hold-token-ip {
    height: 40px;
    border: none;
    border-radius: 5px;
    width: 90%;
    padding: 10px;
  }
  input.hold-token-ip:focus{

  }

  .copy-clip-tok {
    font-size: 20px;
    display: inline-block;
    width: 10%;
  }
  .cont-of-res-api-tok{
    margin: auto;
  }


  .del-send-api-temp {
    text-align: center;
    padding: 10px 0px;
    font-weight: 600;
    color: midnightblue;

  }

  i.fad.fa-acorn {
    font-size: 90px;
    color: #b50a67;
  }

  .txt-data-nt-fd {
    padding: 20px 0px;
    color: black;
    font-weight: 600;

  }
</style>


<div class="modal" data-modal="modal-mngc-api-data">
  <article class="content-wrapper">
    <button class="close"></button>
    <header class="modal-header">
      <h2>Get API Key for managment of list.</h2>
    </header>
    <div class="content">
      <p>Management API Is used for manage contact of contact list. <b>show,delete,add</b> contact from contact list. get your api key and access account from your system. <a class='hrf-doc-lnk' href="">Documentation</a></p>
    </div>



<div class="cont-of-res-api-tok-1">

    <a href="#" class="crt-api-btn-fin" id='mngc' >Generate Token</a>

  </div>
    
  </article>
</div>






<div class="modal" data-modal="modal-send-api-data">
  <article class="content-wrapper">
    <button class="close"></button>
    <header class="modal-header">
      <h2>Create API for send dynamic content</h2>
    </header>
    <div class="content">
      <p>Sending API Is used to get send automayion of your system. like <b>OTP,transactonal message or create campign</b> from your automated system. for help read full <a class='hrf-doc-lnk' href="">Documentation</a></p>
    </div>
   
   

<div class="cont-of-res-api-tok-1">

    <a href="#" class="crt-api-btn-fin" id='send' >Generate Token</a>

  </div>
   
 
  </article>
</div>












  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>
  
  <!--   Optional JS   -->
  
  <!--   Argon JS   -->
  
  

  
</body>


<script type="text/javascript">

token_data={};

id='<?php echo $id;?>';

main_url_of_page="http://heptera.me/dash/main/api/api_temp/";


$(document).ready(function(){

init_api_data(id,function(){




});


init_temp_data(id);


setTimeout(function(){ init_send_api_hist_data(); }, 2000);


set_loader();

});


$(document).on("click","#trg_of_src_lst_dt",function(){


init_send_api_hist_data("search");

});


$(document).on("click",".cls-cop-handl",function(){

copyToClipboard($(this).attr('cop-id'));


console.log($(this).attr('cop-id'));
});

$(document).on("click",".crt-api-btn-fin",function(){

console.log("ravi");

var tp_con=$(this).attr('id');

$.post( "https://api.sycista.com/api/add/"+tp_con+"/"+id, function( data ) {
  
  console.log(data);
   
if(tp_con=='mngc'){
  tp_con=1;
}else{
  tp_con=2;
}


append_act_in_mdl(tp_con,data);

})

});


$(document).on("click",".del-send-api-temp",function(){

del_temp_name=$(this).attr("del-id");



$.ajax({
  type: "POST",
  url: "./ajaxfile/del_temp_api_data.php",
  data:{temp_id:del_temp_name}
  
}).done(function(response1) {

init_temp_data(id);


});



});


const buttons = document.querySelectorAll('.trigger[data-modal-trigger]');

for(let button of buttons) {
  modalEvent(button);
}

function modalEvent(button) {
  button.addEventListener('click', () => {
    const trigger = button.getAttribute('data-modal-trigger');
    const modal = document.querySelector(`[data-modal=${trigger}]`);
    const contentWrapper = modal.querySelector('.content-wrapper');
    const close = modal.querySelector('.close');

    close.addEventListener('click', () => modal.classList.remove('open'));
    modal.addEventListener('click', () => modal.classList.remove('open'));
   

    modal.classList.toggle('open');
  });
}

function copyToClipboard(id) {
  var copyText = document.getElementById("cop-con-"+id);
  copyText.select();
  copyText.setSelectionRange(0, 99999)
  document.execCommand("copy");
  
 
}



function append_act_in_mdl(type,token){


$("#acc-token-handl-"+type).html("<div class='cont-of-res-api-tok'><input class='hold-token-ip' readonly='readonly' value="+token+" id='cop-con-"+type+"' ><div class='copy-clip-tok cls-cop-handl' cop-id='"+type+"'  ><i class='fal fa-copy' aria-hidden='true'></i></div></div>");

}



function init_api_data(id){

console.log(id);
$.get( "https://api.sycista.com/api/all/"+id, function( data ) {
  

$("#suc-rate-of-api-1").html('0');
$("#suc-rate-of-api-2").html('0');


if(data.length>0){


	$(".suc_api-hand-rat-fl-bx").css('display','block');



  for (var i = 0; i < data.length; i++) {
    console.log(data[i].type);



    $("#suc-send-dis-"+data[i].type).css('display','block');

token_data["token"+data[i].type]=data[i].token;
   
   $("#suc-rate-of-api-"+data[i].type).html(data[i].req);

append_act_in_mdl(data[i].type,data[i].token);


  };


}else{





}

});




}


function init_temp_data(id){





$("#temp_to_res").empty();

$("#temp_to_res").html("<div class='lds-ring lds-color'  style=''><div></div><div></div><div></div><div></div></div>");

$.ajax({
  type: "GET",
  url: "./ajaxfile/get_api_temp_data.php"
  
}).done(function(response1) {


  console.log(response1);

if(response1==0){


$("#temp_to_res").html("<div class='not-fd-temp-api-data'> <img src='https://res.cloudinary.com/heptera/image/upload/v1611119685/api/undraw_building_websites_i78t_tuy3cz.svg' style=' height: 200px; '> <div class='txt-data-nt-fd'> Not found any template data for API connect. </div> </div>");


}else{



temp_json_data=JSON.parse(response1);

$("#temp_to_res").html("");


for (var i = 0; i < temp_json_data.length; i++) {
  


temp_thumb(temp_json_data[i].temp_id);

};

   
   }
    
   
});




}



function temp_thumb(temp_id){

  


var str_for_temp_res="<div  class='' style='padding-left:0px;padding-right:0px;margin:auto;'><div class='temp_con'><img class='temp_img_con' data-toggle='modal' data-target='#temp_review_con' src='http://heptera.me/dash/main/template/img-log/300*200.png'  width='200' height='250' id='img-of-temp' /><div class='cont-of-res-api-tok' style='width:100%;'><input class='hold-token-ip' readonly='readonly' value='"+temp_id+"' style='width:170px;' id='cop-con-"+temp_id+"'><div class='copy-clip-tok cls-cop-handl' style='width:30px;' cop-id='"+temp_id+"'><i class='fal fa-copy' aria-hidden='true'></i></div></div><div class='del-send-api-temp' del-id='"+temp_id+"'>Delete <i class='fal fa-trash-restore'></i></div></div></div>";

$("#temp_to_res").append(str_for_temp_res);

get_screen_shot(temp_id);

}







function get_screen_shot(id_of_url){
  
    url=main_url_of_page+id_of_url+".php";
  url_main="http://ec2-3-21-105-231.us-east-2.compute.amazonaws.com/scr-api/?url="+url+"&width=700&height=800"; 



    $("#img-of-temp").attr("src",url_main);
    $("#img-of-temp").attr("id",id_of_url);

//document.getElementById(id_of_url+"img").src=url_main;

console.log(id_of_url);
}




function init_send_api_hist_data(src_name){

src_data=[];



$("#send_api_history").html("<div class='lds-ring lds-color'  style=''><div></div><div></div><div></div><div></div></div>");

if(src_name=="search"){

src_data[0]=$("#src_fld_sel").children("span").attr('id');
src_data[1]=$("#src_fld_val").val();

}

if(src_data[0]=='all'){

src_data=[];

}

src_data=JSON.stringify(src_data);



console.log(src_data);


$.ajax({
  type: "POST",
  url: "./ajaxfile/get_send_table_data.php",
  data:{token:token_data['token2'],src_data:src_data}  
}).done(function(response1) {


if(response1==0){


}else{

  console.log(response1);

data_arr=JSON.parse(response1);

set_email_send_data(data_arr);

}
    
   
});




}


function set_email_send_data(data_arr){
console.log(data_arr);




if(data_arr.length>0){
str_of_app="<table> <thead> <tr> <th>List Name</th> <th>Email</th> <th>Content Info</th> <th>Tag</th> <th>Status</th> </tr> <thead> <tbody>";

for (var i = 0; i < data_arr.length; i++) {

str_of_app+="<tr> <td>"+data_arr[i]['lst_name']+"</td> <td>"+data_arr[i]['email']+"</td> <td>"+data_arr[i]['content_dt']+"</td><td>"+data_arr[i]['tag']+"</td> <td>1</td>  </tr>";

};


str_of_app+="</tbody><table/>";
}else{



str_of_app='<div class="not-fd-temp-api-data"> <img src="https://res.cloudinary.com/heptera/image/upload/v1611120241/api/undraw_to_do_xvvc_vuiyex.svg" style=" height: 200px; "> <div class="txt-data-nt-fd"> You are not send email using sycista API plateform</div> </div>';



}

$("#send_api_history").html(str_of_app);

console.log(str_of_app);


}



function set_loader(){

$(".lds_set_data").html("<div class='lds-ring lds-color'  style=''><div></div><div></div><div></div><div></div></div>");

}


$(".default_option").click(function(){
  $(".dropdown-sel ul").addClass("active");
});

$(".dropdown-sel ul li").click(function(){
  var text = $(this).html();
  $(".default_option").html(text+"<i class='fad fa-chevron-down'></i>");
  $(".dropdown-sel ul").removeClass("active");
});


</script>



</html>



