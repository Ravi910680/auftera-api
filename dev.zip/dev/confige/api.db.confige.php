<?php



function create_db($conn,$db_name){




$sql = "CREATE DATABASE `".$db_name."`";
if ($conn->query($sql) === TRUE) {

echo "create db ".$db_name;

}else{
	echo $conn->error;
}




}



function create_tbl_in_db($conn,$sql){



if($conn->query($sql)==TRUE){

echo "create Table ";

}




}




$servername = "api.cjym2crfj1fu.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";





$main_conn = mysqli_connect($servername, $username, $password);




create_db($main_conn,"heptera-api");
create_db($main_conn,"heptera-api-send-table");



$main_conn = mysqli_connect($servername, $username, $password,"heptera-api");



$sql="CREATE TABLE `api-key` (
 `usr_id` int(10) NOT NULL,
 `type` int(2) NOT NULL,
 `token` varchar(24) NOT NULL,
 `req` int(10) NOT NULL,
 PRIMARY KEY (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";

create_tbl_in_db($main_conn,$sql);

$sql="CREATE TABLE `heptera-api-temp` (
 `usr_id` int(20) NOT NULL,
 `temp_id` varchar(200) NOT NULL,
 PRIMARY KEY (`temp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";

create_tbl_in_db($main_conn,$sql)



?>
